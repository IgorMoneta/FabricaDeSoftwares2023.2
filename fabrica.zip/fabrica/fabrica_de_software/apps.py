from django.apps import AppConfig


class FabricaDeSoftwareConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fabrica_de_software'
