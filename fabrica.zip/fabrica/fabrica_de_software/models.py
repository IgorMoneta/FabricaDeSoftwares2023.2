from django.db import models

class Fabrica_de_softwareList(models.Model):
    tarefa = models.CharField(max_length = 30)
    choices_status = [
        ("Pronto" , "Pronto"),
        ("Em andamento" , "Em andamento"),
        ("Pendente" , "Pendente"),
        ("Conclusão" , "Conclusão")
    ]
    status = models.CharField(choices = choices_status, max_length = 35)