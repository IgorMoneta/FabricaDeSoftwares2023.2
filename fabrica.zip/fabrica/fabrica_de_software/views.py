from django.shortcuts import render
from rest_framework import viewsets
from .models import Fabrica_de_softwareList
from .serializers import Fabrica_de_SoftwareSerializer

class Fabrica_de_softwareViweset(viewsets.ModelViewSet):
    queryset = Fabrica_de_softwareList.objects.all()
    serializer_class = Fabrica_de_SoftwareSerializer