from rest_framework import routers
from .views import Fabrica_de_softwareViweset

router = routers.DefaultRouter()
router.register(r'', Fabrica_de_softwareViweset)
urlpatterns = router.urls