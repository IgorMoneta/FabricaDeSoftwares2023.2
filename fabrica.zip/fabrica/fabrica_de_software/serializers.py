from rest_framework import serializers
from fabrica_de_software.models import Fabrica_de_softwareList

class Fabrica_de_SoftwareSerializer(serializers.ModelSerializer):
    class Meta:
        model = Fabrica_de_softwareList
        fields = "__all__"