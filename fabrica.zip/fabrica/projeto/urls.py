
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('fabrica_de_software', include('fabrica_de_software.urls'))
]
